<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Customer List</title>
    <style>
        table,
        th,
        td {
            padding: 10px;
            border: 1px solid black;
            border-collapse: collapse;
        }
        h1{
            text-align: center;
        }
    </style>
</head>

<body>
    <h1>Customer List</h1>
    <table>
        <thead>
            <tr>
                <th>#SL</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Membership Type</th>
                <th>Discount #</th>
                <th>Created At</th>
                <th>Updated At</th>
                

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($customer->first_name); ?></td>
                <td><?php echo e($customer->last_name); ?></td>
                <td><?php echo e($customer->email); ?></td>
                <td><?php echo e($customer->membership_type); ?></td>
                <td><?php echo e($customer->discount_id); ?></td>
                <td><?php echo e($customer->created_at); ?></td>
                <td><?php echo e($customer->updated_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html><?php /**PATH E:\Projects\bergundi.com\bergundi\resources\views/pdfs/customer.blade.php ENDPATH**/ ?>