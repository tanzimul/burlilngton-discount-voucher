<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Redemption Transactions</title>
    <style>
        table,
        th,
        td {
            padding: 10px;
            border: 1px solid black;
            border-collapse: collapse;
        }

        h2 {
            text-align: center;
        }
    </style>
</head>

<body>
    <h2>Burlington Springs Daily Discount Program – Daily Redemptions</h2>
    <h4>Date : <?php echo e($date); ?></h4>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th><strong>Paper</strong></th>
                <th><strong>Phone</strong></th>
                <th><strong>Total</strong></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><strong>Regular</strong></td>
                <td><?php echo e($paperRegularCount); ?></td>
                <td><?php echo e($phoneRegularCount); ?></td>
                <td><?php echo e($sumOfRegular); ?></td>
            </tr>
            <tr>
                <td><strong>Senior</strong></td>
                <td><?php echo e($paperSeniorCount); ?></td>
                <td><?php echo e($phoneSeniorCount); ?></td>
                <td><?php echo e($sumOfSenior); ?></td>
            </tr>
            <tr>
                <td><strong>Frequent Flyer</strong></td>
                <td></td>
                <td></td>
                <td><?php echo e($sumOfFlyer); ?></td>
            </tr>


        </tbody>
        <tfoot>
            <tr>
                <th><strong>Total</strong></th>
                <th><?php echo e($totalPaper); ?></th>
                <th><?php echo e($totalPhone); ?></th>
                <th><?php echo e($subTotal); ?></th>
            </tr>
        </tfoot>
    </table>
</body>

</html><?php /**PATH E:\Projects\bergundi.com\bergundi\resources\views/pdfs/reconciliation.blade.php ENDPATH**/ ?>