<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Reports</div>
                <form action="<?php echo e(route('export')); ?>" method="post" id="exportReportForm">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="custom-control custom-radio pt-2">
                                    <input type="radio" class="custom-control-input" id="report1" name="report" value="customer_record" required checked>
                                    <label class="custom-control-label border rounded w-100 p-4" for="report1">Customer Records</label>
                                </div>
                            </div>
                            <div class="col-md-6"></div>
                            <div class="col-md-6">
                                <div class="custom-control custom-radio pt-2">
                                    <input type="radio" class="custom-control-input" id="report2" name="report" value="redemption_transactions" required>
                                    <label class="custom-control-label border rounded w-100 p-4" for="report2">Redemption Transactions</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row" id="fromTo">
                                    <div class="col">
                                        <label for="fromDate" class="col-form-label">From:</label>
                                        <input type="text" class="form-control" id="fromDate" name="from"/>
                                    </div>
                                    <div class="col">
                                        <label for="toDate" class="col-form-label">To:</label>
                                        <input type="text" class="form-control" id="toDate" name="to"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="custom-control custom-radio pt-2">
                                    <input type="radio" class="custom-control-input" id="report3" name="report" value="daily_reconciliation" required>
                                    <label class="custom-control-label border rounded w-100 p-4" for="report3">Daily Reconciliation</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col">
                                        <label for="dailyDate" class="col-form-label">Date:</label>
                                        <input type="text" class="form-control" id="dailyDate" name="date" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-success">Export</button>
                        </div>
                        <div class="mt-4">
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger" id="alertMessage">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                            <div class="alert alert-success" id="alertMessage">
                                <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger" id="alertMessage">
                                <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\bergundi.com\bergundi\resources\views/admin/report.blade.php ENDPATH**/ ?>